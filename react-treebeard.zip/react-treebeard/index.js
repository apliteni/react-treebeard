var { Treebeard, decorators } = require('./dist');
module.exports = {
    Treebeard,
    decorators,
};
